import java.io.IOException;
import java.util.Hashtable;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import com.ibm.mq.MQException;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQPutMessageOptions;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;


public class RJComSendMQMessage {

	

	public void putMessage(String messageContent, String hostname, String queueManagerName, String channel,
			Integer port, String queueName) throws MQException, IOException {
		MQQueue queue = null;
		MQQueueManager queueManager = null;
		try {
			queueManager = createQueueManager(queueManagerName, hostname, channel, port);
			queue = createQueue(queueManager, queueName, 16);
			MQMessage message = new MQMessage();
			message.format = "MQSTR   ";
			message.writeString(messageContent);
			/*
			 * if (logger.isLoggable(Level.FINEST)) logger.log(Level.FINEST,
			 * "Write message content: " + messageContent);
			 */
			MQPutMessageOptions pmo = new MQPutMessageOptions();
			queue.put(message, pmo);
		} finally {
			if (queue != null)
				queue.close();
			if (queueManager != null)
				queueManager.disconnect();
		}
	}
	
	private MQQueue createQueue(MQQueueManager queueManager, String queueName, int openOptions) throws MQException {
		return queueManager.accessQueue(queueName, openOptions, null, null, null);
	}

	private MQQueueManager createQueueManager(String queueManagerName, String hostname, String channel, Integer port)
			throws MQException {
		Hashtable<Object, Object> queueManagerProperties = new Hashtable<Object, Object>();
		queueManagerProperties.put("hostname", hostname);
		queueManagerProperties.put("channel", channel);
		queueManagerProperties.put("port", port);
		// return new MQQueueManager(queueManagerName, queueManagerProperties);
		return new MQQueueManager(queueManagerName, queueManagerProperties);
	}
	//
	
	public void putMessageViaCF(String messageContent, String connectionFactory, String sendQName)
			throws MQException, IOException, NamingException, JMSException{
		
		Connection putConnection = null;
		Session putSession= null;
		try {
			InitialContext ctx = new InitialContext();
			ConnectionFactory putConnectionFactory = (ConnectionFactory) ctx.lookup(connectionFactory);  
			putConnection = putConnectionFactory.createConnection();
			Queue destination = (Queue) ctx.lookup(sendQName);
			putConnection.start();
			putSession = putConnection.createSession(true, Session.AUTO_ACKNOWLEDGE);
			MessageProducer producer = putSession.createProducer(destination);
			
			TextMessage message = putSession.createTextMessage(messageContent);
			producer.send(message);
			putSession.close();
			putConnection.close();
		} finally {
			
			if (putSession != null) {
				putSession.close();
		    }

		    if (putConnection != null) {
		    	putConnection.close();
		    }
		   
		}

	}
	
	public void putMessageViaCF4(String messageContent, String connectionFactory, String sendQName)
			throws MQException, IOException, NamingException, JMSException{
		
		try {
			InitialContext ctx = new InitialContext();
			ConnectionFactory putConnectionFactory = (ConnectionFactory) ctx.lookup("jms/SORC_QM_CF");  
			Connection putConnection = putConnectionFactory.createConnection();
			Queue destination = (Queue) ctx.lookup("jms/SORC_SEND_Q");
			putConnection.start();
			Session putSession = putConnection.createSession(true, Session.AUTO_ACKNOWLEDGE);
			MessageProducer producer = putSession.createProducer(destination);
			
			TextMessage message = putSession.createTextMessage(messageContent);
			producer.send(message);
			putSession.close();
			putConnection.close();
		} finally {
			
			
		   
		}

	}
	
}
